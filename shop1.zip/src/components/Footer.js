import React from "react";

const Footer = () => {
  let foo = {
    color: "#fff",
    backgroundColor: "#000",
    padding: "20px 0px",
    marginTop: "80px",
  };
  return (
    <>
      <p style={foo}>COPYRIGHT(C) 2025 과일농장, Inc. All Rights Reserved</p>
    </>
  );
};

export default Footer;
